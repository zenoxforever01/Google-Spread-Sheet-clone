package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;


public class MainActivity extends AppCompatActivity {

    private static final int NUM_ROWS = 10;
    private static final int NUM_COLS = 5;

    private RecyclerView gridRecyclerView;
    private GridAdapter gridAdapter;

    private String[][] gridData = new String[NUM_ROWS][NUM_COLS];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridRecyclerView = findViewById(R.id.gridRecyclerView);

        initializeGridData();

        gridAdapter = new GridAdapter(gridData);
        gridRecyclerView.setLayoutManager(new GridLayoutManager(this, NUM_COLS));
        gridRecyclerView.setAdapter(gridAdapter);
    }

    private void initializeGridData() {
        for (int i = 0; i < NUM_ROWS; i++) {
            for (int j = 0; j < NUM_COLS; j++) {
                gridData[i][j] = "";
            }
        }
    }

    // Inner class for GridAdapter
    private class GridAdapter extends RecyclerView.Adapter<GridAdapter.GridViewHolder> {

        private String[][] gridData;

        public GridAdapter(String[][] gridData) {
            this.gridData = gridData;
        }

        @Override
        public GridViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item, parent, false);
            return new GridViewHolder(view);
        }

        @Override
        public void onBindViewHolder(GridViewHolder holder, int position) {
            int row = position / NUM_COLS;
            int col = position % NUM_COLS;
            holder.editText.setText(gridData[row][col]);
            holder.editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        int adapterPosition = holder.getAdapterPosition();
                        int row = adapterPosition / NUM_COLS;
                        int col = adapterPosition % NUM_COLS;
                        gridData[row][col] = holder.editText.getText().toString();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return NUM_ROWS * NUM_COLS;
        }

        // Inner class for GridViewHolder
        class GridViewHolder extends RecyclerView.ViewHolder {
            EditText editText;

            GridViewHolder(View itemView) {
                super(itemView);
                editText = itemView.findViewById(R.id.editText);
            }
        }
    }
}
